package com.example.baccalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
/*
    Assignment: Homework 01
    File Name: MainActivity.java
    Full Name: Saifuddin Mohammed, Juhi Jadhav
    Group number: 05
*/

public class MainActivity extends AppCompatActivity {

    TextView result;
    TextView result_2;
    EditText weight;
    Button output;
    RadioGroup gender;
    RadioGroup size;
    SeekBar percentage;
    Button reset;
    Button calculate;
    TextView percentageText;
    TextView drinks_consumed;
    TextView status;
    TextView total_alcohol;

    public void initializeObjects()
    {
        result = findViewById(R.id.show_weight);
        result_2 = findViewById(R.id.show_weight2);
        output = findViewById(R.id.set_weight_button);
        gender = findViewById(R.id.radio_gender);
        weight = findViewById(R.id.enter_weight);
        size = findViewById(R.id.radio_drink);
        percentage = findViewById(R.id.seekBar);
        reset = findViewById(R.id.reset_button);
        calculate = findViewById(R.id.add_drink);
        percentageText = findViewById(R.id.BAC_level);
        drinks_consumed = findViewById(R.id.total_drinks);
        status = findViewById(R.id.status);
        total_alcohol = findViewById(R.id.percentage_alcohol);
        weight.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);

    }

    @SuppressLint("SetTextI18n")
    public void clearAll()
    {
        weight.setText("");
        result.setText("");
        result_2.setText("");
        percentage.setProgress(0);
        drinks_consumed.setText("0");
        total_alcohol.setText("0%");
        status.setText("You're safe");
        percentageText.setText("0.000");
        status.setBackgroundColor(Color.parseColor("#247003"));
        calculate.setEnabled(true);
    }


    @SuppressLint({"SetTextI18n"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final String tag = "BAC Calculator";
        initializeObjects();

        percentage.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            public void onStopTrackingTouch(SeekBar bar) {
                int value = bar.getProgress();
            }

            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            public void onProgressChanged(SeekBar bar, int paramInt, boolean paramBoolean) {
                total_alcohol.setText(paramInt + "%");
            }
        });

        output.setOnClickListener(v -> {
            String weight_value = weight.getText().toString();
            int radio_button_id = gender.getCheckedRadioButtonId();

            if (weight_value.isEmpty() && gender.getCheckedRadioButtonId() == -1 || weight_value.equals("0") || weight_value.equals("null")) {
                Toast.makeText(MainActivity.this, "Please enter the correct weight and gender first", Toast.LENGTH_SHORT).show();
            } else {
                size.clearCheck();
                drinks_consumed.setText("0");
                percentage.setProgress(0);
                total_alcohol.setText("0%");
                weight.setText("");
                percentageText.setText("0.000");
                status.setText("You're safe");
                result.setText("");
                result_2.setText("");
                status.setBackgroundColor(Color.parseColor("#247003"));
                calculate.setEnabled(true);


                if (radio_button_id == R.id.female) {
                    result.setText(weight_value);
                    result_2.setText("(female)");
                }

                if (radio_button_id == R.id.male) {
                    result.setText(weight_value);
                    result_2.setText("(male)");
                }


            }
        });


            calculate.setOnClickListener(v2 -> {
                int radio_button_id_2 = size.getCheckedRadioButtonId();
                String weight_t = result.getText().toString();

                if (weight_t.isEmpty() || size.getCheckedRadioButtonId() == -1 || gender.getCheckedRadioButtonId() == -1) {
                    Toast.makeText(MainActivity.this, "Please enter your weight, gender and drink size", Toast.LENGTH_SHORT).show();
                } else {

                    String drinks = drinks_consumed.getText().toString();
                    int drinks_1 = Integer.parseInt(drinks);
                    drinks_1++;
                    drinks_consumed.setText(String.valueOf(drinks_1));
                    double current_BAC = Double.parseDouble(percentageText.getText().toString());


                    if (radio_button_id_2 == R.id.one_oz) {
                        String S = total_alcohol.getText().toString();
                        String[] S1 = S.split("%");
                        int S2 = Integer.parseInt(S1[0]);
                        double S3 = (S2 / 100.0) * 1;
                        if (gender.getCheckedRadioButtonId() == R.id.female) {
                            current_BAC += S3 * 5.14 / (Double.parseDouble(weight_t) * 0.66);
                            percentageText.setText(String.format("%.3f", current_BAC));
                        } else {
                            current_BAC += S3 * 5.14 / (Double.parseDouble(weight_t) * 0.73);
                            percentageText.setText(String.format("%.3f", current_BAC));
                        }
                    } else if (radio_button_id_2 == R.id.five_oz) {
                        String S = total_alcohol.getText().toString();
                        String[] S1 = S.split("%");
                        int S2 = Integer.parseInt(S1[0]);
                        double S3 = (S2 / 100.0) * 5;
                        if (gender.getCheckedRadioButtonId() == R.id.female) {
                            current_BAC += S3 * 5.14 / (Double.parseDouble(weight_t) * 0.66);
                            percentageText.setText(String.format("%.3f", current_BAC));
                        } else {
                            current_BAC += S3 * 5.14 / (Double.parseDouble(weight_t) * 0.73);
                            percentageText.setText(String.format("%.3f", current_BAC));
                        }
                    } else if (radio_button_id_2 == R.id.twelve_oz) {
                        String S = total_alcohol.getText().toString();
                        String[] S1 = S.split("%");
                        int S2 = Integer.parseInt(S1[0]);
                        double S3 = (S2 / 100.0) * 12;
                        if (gender.getCheckedRadioButtonId() == R.id.female) {
                            current_BAC += S3 * 5.14 / (Double.parseDouble(weight_t) * 0.66);
                            percentageText.setText(String.format("%.3f", current_BAC));
                        } else {
                            current_BAC += S3 * 5.14 / (Double.parseDouble(weight_t) * 0.73);
                            percentageText.setText(String.format("%.3f", current_BAC));
                        }

                    }
                    if (current_BAC >0.25) {
                        Toast.makeText(MainActivity.this,"No more drinks for you", Toast.LENGTH_SHORT).show();
                        calculate.setEnabled(false);
                    }
                    else if (current_BAC>=0 && current_BAC<=0.08) {
                        status.setText("You're safe");
                        status.setBackgroundColor(Color.parseColor("#247003"));
                    }
                    else if (current_BAC>0.08 && current_BAC<=0.20) {
                        status.setText("Be careful");
                        status.setBackgroundColor(Color.parseColor("#FF9800"));
                    }
                    else if (current_BAC>0.20 ) {
                        status.setText("You're over the limit");
                        status.setBackgroundColor(Color.RED);
                    }



                }



            });

            reset.setOnClickListener(v3 -> {
                clearAll();
            });
        }

}

